package com.example.bajp_submission3.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
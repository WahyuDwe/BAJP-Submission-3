package com.example.bajp_submission3.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}